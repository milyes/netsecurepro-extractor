import streamlit as st
from PIL import Image
from pdf2image import convert_from_path
from ai_auto import auto_restore
from ia_logic import analyze_image
from ai_clrm import clrm_analyze
from ai_ocr import ocr_process
from generate_report import generate_pdf, generate_json, generate_audio
from pathlib import Path
import tempfile

st.set_page_config(page_title="IA Document Analyzer", layout="wide")
st.title("📄🧠 Plateforme IA Multiformat – Analyse, OCR, PDF, Audio")
st.write("Uploader un fichier (PDF, scan ou image) pour obtenir une analyse IA complète et un rapport intelligent.")

uploaded_file = st.file_uploader("Uploader un fichier", type=["pdf", "png", "jpg", "jpeg", "bmp", "webp", "tiff"])

if uploaded_file:
    temp_dir = tempfile.TemporaryDirectory()
    file_path = Path(temp_dir.name) / uploaded_file.name
    with open(file_path, "wb") as f:
        f.write(uploaded_file.read())

    st.success(f"✅ Fichier reçu : {uploaded_file.name}")

    images = []
    if file_path.suffix.lower() == ".pdf":
        images = convert_from_path(str(file_path), dpi=300)
        st.info(f"{len(images)} page(s) détectée(s) dans le PDF.")
    else:
        images = [Image.open(file_path)]

    for i, img in enumerate(images):
        st.subheader(f"🖼️ Page {i + 1}")
        temp_img_path = Path(temp_dir.name) / f"page_{i+1:03}.png"
        img.save(temp_img_path)

        st.image(temp_img_path, caption="Image originale", use_column_width=True)

        # Restauration AI_auto
        restored_path = Path(temp_dir.name) / f"restored_{i+1:03}.png"
        auto_restore(temp_img_path, restored_path)
        st.image(restored_path, caption="Restaurée par AI_auto", use_column_width=True)

        # Analyse IA_LOGIC
        logic_result = analyze_image(restored_path)
        st.success(f"IA_LOGIC : {logic_result}")

        # Analyse AI_CLRM
        clrm = clrm_analyze(restored_path)
        st.info(f"AI_CLRM Note : {clrm['note']}")
        st.info(f"AI_CLRM Suggestion : {clrm['suggestion']}")

        # OCR
        text = ocr_process(restored_path)
        st.text_area("Texte OCR extrait", text, height=150)

        # Génération des rapports
        Path("output").mkdir(exist_ok=True)
        stem = f"{file_path.stem}_page{i+1:03}"
        generate_pdf({
            "logic_result": logic_result,
            "clrm_result": clrm,
            "ocr_text": text
        }, f"output/rapport_{stem}.pdf")

        generate_json({
            "logic_result": logic_result,
            "clrm_result": clrm,
            "ocr_text": text
        }, f"output/result_{stem}.json")

        generate_audio(text, f"output/rapport_{stem}.mp3")

        # Liens de téléchargement
        st.download_button("📄 Télécharger PDF", data=open(f"output/rapport_{stem}.pdf", "rb").read(), file_name=f"rapport_{stem}.pdf")
        st.download_button("🧾 Télécharger JSON", data=open(f"output/result_{stem}.json", "rb").read(), file_name=f"result_{stem}.json")
        st.download_button("🔊 Télécharger Audio", data=open(f"output/rapport_{stem}.mp3", "rb").read(), file_name=f"rapport_{stem}.mp3")
